export interface MerkleNode {
  hash: string;
  left?: MerkleNode;
  right?: MerkleNode;
  data?: string;
  level: number;
  index?: number;
}

export interface ProofNode {
  hash: string;
  isLeft: boolean;
}

export interface MerkleProof {
  leafHash: string;
  proof: ProofNode[];
  rootHash: string;
  leafData: string;
  leafIndex: number;
}