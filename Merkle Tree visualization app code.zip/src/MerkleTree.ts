import { sha256 } from './utils/hash';
import { MerkleNode, ProofNode } from './types';

export class MerkleTree {
  root: MerkleNode | null = null;
  leaves: string[] = [];
  originalRootHash: string = '';

  constructor(leaves: string[] = []) {
    if (leaves.length > 0) {
      this.build(leaves);
    }
  }

  async build(leaves: string[]): Promise<void> {
    this.leaves = [...leaves];
    
    if (leaves.length === 0) {
      this.root = null;
      return;
    }

    const paddedLeaves = this.padToPowerOfTwo(leaves);
    
    const leafNodes: MerkleNode[] = await Promise.all(
      paddedLeaves.map(async (data, index) => ({
        hash: await sha256(data),
        data,
        level: 0,
        index,
      }))
    );

    this.root = await this.buildLevel(leafNodes, 1);
    this.originalRootHash = this.root?.hash || '';
  }

  private padToPowerOfTwo(leaves: string[]): string[] {
    const n = leaves.length;
    if (n === 0) return [];
    if (n === 1) return leaves;
    const nextPower = Math.pow(2, Math.ceil(Math.log2(n)));
    const padded = [...leaves];
    while (padded.length < nextPower) {
      padded.push(leaves[leaves.length - 1]);
    }
    return padded;
  }

  private async buildLevel(nodes: MerkleNode[], level: number): Promise<MerkleNode> {
    if (nodes.length === 1) {
      return nodes[0];
    }

    const parentNodes: MerkleNode[] = [];
    for (let i = 0; i < nodes.length; i += 2) {
      const left = nodes[i];
      const right = nodes[i + 1];
      const combinedHash = left.hash + right.hash;
      const parentHash = await sha256(combinedHash);
      
      parentNodes.push({
        hash: parentHash,
        left,
        right,
        level,
        index: i / 2,
      });
    }

    return this.buildLevel(parentNodes, level + 1);
  }

  getProof(leafIndex: number): ProofNode[] {
    const proof: ProofNode[] = [];
    
    const traverse = (current: MerkleNode | undefined, targetIndex: number): void => {
      if (!current || current.level === 0) {
        return;
      }

      const isLeftChild = targetIndex % 2 === 0;
      const sibling = isLeftChild ? current.right : current.left;
      
      if (sibling) {
        proof.push({
          hash: sibling.hash,
          isLeft: !isLeftChild,
        });
      }

      const nextIndex = Math.floor(targetIndex / 2);
      const nextNode = isLeftChild ? current.left : current.right;
      
      traverse(nextNode, nextIndex);
    };

    traverse(this.root, leafIndex);
    return proof;
  }

  async verifyProof(leafHash: string, proof: ProofNode[], rootHash: string): Promise<boolean> {
    let currentHash = leafHash;
    
    for (const node of proof) {
      if (node.isLeft) {
        currentHash = await sha256(node.hash + currentHash);
      } else {
        currentHash = await sha256(currentHash + node.hash);
      }
    }
    
    return currentHash === rootHash;
  }

  isTampered(): boolean {
    return this.root?.hash !== this.originalRootHash;
  }
}