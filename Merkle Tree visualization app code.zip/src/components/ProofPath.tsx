import React from 'react';
import { ProofNode } from '../types';
import { ArrowRight, CheckCircle, AlertTriangle } from 'lucide-react';

interface ProofPathProps {
  proof: ProofNode[];
  leafHash: string;
  rootHash: string;
  isValid: boolean;
  computedRoot?: string;
}

export function ProofPath({ proof, leafHash, rootHash, isValid, computedRoot }: ProofPathProps) {
  if (proof.length === 0) {
    return (
      <div className="text-slate-400 text-center py-8">
        Select a leaf to see its proof path
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-slate-200">Authentication Path</h3>
        {isValid ? (
          <div className="flex items-center gap-2 text-green-400">
            <CheckCircle className="w-5 h-5" />
            <span>Valid Proof</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-red-400">
            <AlertTriangle className="w-5 h-5" />
            <span>Invalid Proof</span>
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="text-xs text-slate-400 mb-1">Leaf Hash</div>
          <div className="font-mono text-sm text-slate-200">{leafHash.slice(0, 32)}...</div>
        </div>

        {proof.map((node, index) => (
          <div key={index} className="flex items-center gap-3">
            <ArrowRight className="w-5 h-5 text-slate-500 flex-shrink-0" />
            <div className="flex-1 bg-amber-900/30 border border-amber-700 rounded-lg p-4">
              <div className="text-xs text-amber-400 mb-1">
                Sibling Hash (Level {index + 1}) - {node.isLeft ? 'Left' : 'Right'}
              </div>
              <div className="font-mono text-sm text-slate-200">{node.hash.slice(0, 32)}...</div>
            </div>
          </div>
        ))}

        {computedRoot && (
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
            <div className="text-xs text-slate-400 mb-1">Computed Root</div>
            <div className="font-mono text-sm text-slate-200">{computedRoot.slice(0, 32)}...</div>
          </div>
        )}

        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="text-xs text-slate-400 mb-1">Stored Root</div>
          <div className="font-mono text-sm text-slate-200">{rootHash.slice(0, 32)}...</div>
        </div>
      </div>

      <div className="text-xs text-slate-500 text-center">
        Only {proof.length} sibling hashes needed to verify membership
      </div>
    </div>
  );
}