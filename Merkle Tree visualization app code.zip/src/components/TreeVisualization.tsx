import React from 'react';
import { MerkleNode } from '../types';
import { Hash } from 'lucide-react';

interface TreeVisualizationProps {
  root: MerkleNode | null;
  selectedLeafIndex?: number;
  proofHashes: string[];
  onLeafClick: (index: number) => void;
}

export function TreeVisualization({ root, selectedLeafIndex, proofHashes, onLeafClick }: TreeVisualizationProps) {
  if (!root) {
    return (
      <div className="flex items-center justify-center h-96 text-slate-400">
        <p>Enter leaf data to build the tree</p>
      </div>
    );
  }

  const height = root.level;
  const levels: MerkleNode[][] = [];

  for (let i = 0; i <= height; i++) {
    levels.push(getNodesAtLevel(root, i));
  }

  return (
    <div className="flex flex-col gap-4 overflow-x-auto pb-4">
      {levels.map((level, levelIndex) => (
        <div key={levelIndex} className="flex justify-center gap-2">
          {level.map((node, nodeIndex) => {
            const isSelected = levelIndex === 0 && nodeIndex === selectedLeafIndex;
            const isInProof = proofHashes.includes(node.hash);
            
            return (
              <div
                key={nodeIndex}
                onClick={() => levelIndex === 0 && onLeafClick(nodeIndex)}
                className={`
                  relative min-w-32 p-3 rounded-lg border-2 transition-all cursor-pointer
                  ${isSelected ? 'bg-blue-600 border-blue-400 scale-105' : ''}
                  ${isInProof && !isSelected ? 'bg-amber-600 border-amber-400' : ''}
                  ${!isSelected && !isInProof ? 'bg-slate-800 border-slate-700' : ''}
                  ${levelIndex === 0 ? 'hover:bg-slate-700' : ''}
                `}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Hash className="w-4 h-4 text-slate-400" />
                  <span className="text-xs text-slate-400">
                    {levelIndex === 0 ? 'Leaf' : `Level ${levelIndex}`}
                  </span>
                </div>
                <div className="font-mono text-xs text-slate-200 break-all">
                  {node.hash.slice(0, 16)}...
                </div>
                {node.data && (
                  <div className="mt-2 text-xs text-slate-400 truncate">
                    {node.data}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function getNodesAtLevel(root: MerkleNode, level: number): MerkleNode[] {
  const nodes: MerkleNode[] = [];
  
  function traverse(node: MerkleNode | undefined): void {
    if (!node) return;
    if (node.level === level) {
      nodes.push(node);
      return;
    }
    traverse(node.left);
    traverse(node.right);
  }
  
  traverse(root);
  return nodes;
}