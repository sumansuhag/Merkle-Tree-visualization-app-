import React, { useState, useEffect } from 'react';
import { MerkleTree } from './MerkleTree';
import { MerkleProof } from './types';
import { TreeVisualization } from './components/TreeVisualization';
import { ProofPath } from './components/ProofPath';
import { Button } from '../components/ui/button';
import { Textarea } from '../components/ui/textarea';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export default function App() {
  const [merkleTree] = useState(() => new MerkleTree());
  const [leafInput, setLeafInput] = useState('Transaction A\nTransaction B\nTransaction C\nTransaction D');
  const [selectedProof, setSelectedProof] = useState<MerkleProof | null>(null);
  const [isValid, setIsValid] = useState(false);
  const [computedRoot, setComputedRoot] = useState<string>('');
  const [isTampered, setIsTampered] = useState(false);

  useEffect(() => {
    buildTree();
  }, []);

  async function buildTree() {
    const leaves = leafInput.split('\n').filter(l => l.trim());
    await merkleTree.build(leaves);
    setSelectedProof(null);
    setIsTampered(false);
  }

  async function handleLeafClick(index: number) {
    const proof = merkleTree.getProof(index);
    const leafData = merkleTree.leaves[index];
    const leafHash = await merkleTree.root?.left?.left?.hash || '';
    
    const proofData: MerkleProof = {
      leafHash: await sha256(leafData),
      proof,
      rootHash: merkleTree.root?.hash || '',
      leafData,
      leafIndex: index,
    };

    setSelectedProof(proofData);
    
    const valid = await merkleTree.verifyProof(
      proofData.leafHash,
      proof,
      proofData.rootHash
    );
    setIsValid(valid);
    setIsTampered(merkleTree.isTampered());
  }

  async function handleLeafEdit(index: number, newValue: string) {
    const newLeaves = [...merkleTree.leaves];
    newLeaves[index] = newValue;
    await merkleTree.build(newLeaves);
    setIsTampered(merkleTree.isTampered());
    
    if (selectedProof) {
      const proof = merkleTree.getProof(selectedProof.leafIndex);
      const valid = await merkleTree.verifyProof(
        await sha256(newLeaves[selectedProof.leafIndex]),
        proof,
        merkleTree.root?.hash || ''
      );
      setIsValid(valid);
    }
  }

  async function sha256(message: string): Promise<string> {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  const proofHashes = selectedProof ? selectedProof.proof.map(p => p.hash) : [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-slate-100 mb-2">MerkleProof</h1>
          <p className="text-slate-400">Visualize Merkle Tree Membership Proofs</p>
        </header>

        {isTampered && (
          <div className="mb-6 bg-red-900/30 border border-red-700 rounded-lg p-4 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <div>
              <div className="font-semibold text-red-400">Tampering Detected!</div>
              <div className="text-sm text-slate-300">Root hash no longer matches original</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-slate-100">Leaf Data</CardTitle>
                <CardDescription className="text-slate-400">
                  Enter data (one per line) to build the Merkle Tree
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={leafInput}
                  onChange={(e) => setLeafInput(e.target.value)}
                  placeholder="Enter leaf data..."
                  className="bg-slate-800 border-slate-700 text-slate-100 min-h-32 font-mono text-sm"
                />
                <Button onClick={buildTree} className="bg-blue-600 hover:bg-blue-700">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Build Tree
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-slate-100">Merkle Tree Visualization</CardTitle>
                <CardDescription className="text-slate-400">
                  Click on any leaf node to see its proof path
                </CardDescription>
              </CardHeader>
              <CardContent>
                <TreeVisualization
                  root={merkleTree.root}
                  selectedLeafIndex={selectedProof?.leafIndex}
                  proofHashes={proofHashes}
                  onLeafClick={handleLeafClick}
                />
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-slate-100">Proof of Membership</CardTitle>
                <CardDescription className="text-slate-400">
                  Authentication path for selected leaf
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ProofPath
                  proof={selectedProof?.proof || []}
                  leafHash={selectedProof?.leafHash || ''}
                  rootHash={merkleTree.root?.hash || ''}
                  isValid={isValid}
                  computedRoot={computedRoot}
                />
              </CardContent>
            </Card>

            {selectedProof && (
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-slate-100">Edit Leaf</CardTitle>
                  <CardDescription className="text-slate-400">
                    Modify leaf to see tampering detection
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm text-slate-400">Leaf Value</label>
                    <Input
                      value={merkleTree.leaves[selectedProof.leafIndex] || ''}
                      onChange={(e) => handleLeafEdit(selectedProof.leafIndex, e.target.value)}
                      className="bg-slate-800 border-slate-700 text-slate-100"
                    />
                  </div>
                  <div className="text-xs text-slate-500">
                    Editing this leaf will change all hashes up the path to the root
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}